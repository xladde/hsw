
package polymorphie.seminar2;

/**
 * Klasse Angestellter ist Abstrakt, da sie abstrakte Methoden besitzt.
 * @author Thomas Jonitz
 */
public abstract class Angestellter {

    // INSTANZVARIABLEN (Protected für Vererbung)
    protected String name;
    protected int id;

    // KEIN KONSTRUKTOR (WEIL NICHT BENÖTIGT)

    /**
     * Abstrakte Methode bruttoGehalt() zum errechnen des bruttogehaltes.
     * Die Methode wird hier deklariert
     * @return Double des bruttogehaltes
     */
    public abstract double bruttoGehalt();

    /**
     * Nettogehalt errechnet sich aus Jahresgehalt abzüglich
     * Sozialversicherung und Steuern. Der Betrag wird auf die Monate des Jahres
     * aufgeteilt
     * @return Double-Wert als Netto-Gehalt
     */
    public double nettoGehalt(){
        double brutto = 12*bruttoGehalt();
        double steuer = berechneSteuer(brutto);
        double vers = sozialVersicherung(brutto);
        return (brutto - (steuer+vers))/12;
    }

    // ZUGRIFF AUF INSTANZVARIABLEN
    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    
    /**
     * Methode zum berechnen der Steuern
     * @param brutto Double-Wert, als Jahres-Bruttogehat
     * @return Double-Wert als zu Gehaltsabhängige Steuer
     */
    private double berechneSteuer(double brutto) {
        double steuer;
        if(brutto > 40000){
            steuer = 6720+0.36*(brutto-40000);
        } else if(brutto > 16000) {
            steuer = 960+0.24*(brutto - 16000);
        } else if(brutto > 8000) {
            steuer = 0.12*(brutto-8000);
        } else {
            steuer = 0;
        }
        return steuer;
    }

    /**
     * Sozialversicherungsabgaben ermitteln (20% des Jahresgehaltes)
     * @param brutto Jahresbruttogehalt
     * @return Sozialversicherungsbeitrag
     */
    private double sozialVersicherung(double brutto) {
        return 0.2*brutto;
    }

}
