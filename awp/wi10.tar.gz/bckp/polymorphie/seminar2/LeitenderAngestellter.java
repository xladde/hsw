
package polymorphie.seminar2;

/**
 *
 * @author ...
 */
public class LeitenderAngestellter {
    //Analog zu Arbeiter
}
