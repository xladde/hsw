
package polymorphie.seminar2;

/**
 * Klasse Arbeiter erbt von Angestellter
 * und bringt alle Methoden und Instanzvariablen mit (Public/protected)
 * @author Thomas Jonitz
 */
public class Arbeiter extends Angestellter {

    // INSTANZVARIABLEN
    private double stundenSatz;
    private double stunden;

    // KONSTRUKTOR
    public Arbeiter(String name, int id, double stundenS){
        this.setId(id);
        this.setName(name);
        stundenSatz = stundenS;
        stunden = 0;
    }

    // mehr stunden Arbeiten
    public void addStunden(double s){
        stunden += s;
    }

    /**
     * Bruttogehaltsmethode überschreiben
     * Hier wird der Rumpf aus der Basisklasse definiert
     * @return
     */
    @Override
    public double bruttoGehalt() {
        return stunden*stundenSatz;
    }
    
    
}
