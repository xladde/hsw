
package polymorphie.seminar1;

/**
 *
 * @author Thomas Jonitz
 */
public class Arbeiter extends Angestellter{

    public double stundensatz;
    public static double gearbeitet;
   

    public Arbeiter(String name, int id, String abteilung) {
        setName(name);
        setpNr(id);
        setAbteilung(abteilung);
        stundensatz = 15;
        gearbeitet = 0;
    }

    public void setStunden(double s){
        gearbeitet += s;
    }

    @Override
    public double bruttoEntgeld() {
        return gearbeitet*stundensatz;
    }
}
