
package polymorphie.seminar1;

/**
 *
 * @author Thomas Jonitz
 */
public abstract class Angestellter {

    private String name;
    private int pNr;
    private String abteilung;

    public abstract double bruttoEntgeld();

    public void setAbteilung(String abteilung) {
        this.abteilung = abteilung;
    }

    public String getAbteilung() {
        return abteilung;
    }

    public String getName() {
        return name;
    }

    public int getpNr() {
        return pNr;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setpNr(int pNr) {
        this.pNr = pNr;
    }
    
    public double nettoEntgeld(){
        double brutto = 12*bruttoEntgeld();
        double steuern = ermittleSteuern(brutto);
        double versicherung = ermittleSozialVersicherung(brutto);
        return (brutto -(steuern+versicherung))/12;
    }

    public double ermittleSteuern(double brutto){
        double steuer;
        if(brutto>40000){
            steuer = 6720+0.36*(brutto - 40000);
        }
        else if(brutto > 16000){
            steuer = 960+0.24*(brutto - 16000);
        }
        else if(brutto > 8000) {
            steuer = 0.12*(brutto - 8000);
        }
        else {
            steuer = 0;
        }
        return steuer;
    }

    public double ermittleSozialVersicherung(double b){
        return b*0.2;
    }



}
