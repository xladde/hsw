
package polymorphie.seminar1;

/**
 *
 * @author Thomas Jonitz
 */
public class LeitenderAngestellter {

}
