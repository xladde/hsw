
package polymorphie;

import polymorphie.seminar2.*;

/**
 *
 * @author Thomas Jonitz
 */
public abstract class Main {

    public static void main(String[] args){
        Arbeiter a = new Arbeiter("Fritz Meyer", 111, 8.50);
        a.addStunden(40*48); // 40 Stunden * 48 Wochen
        System.out.println("Bruttolohn von a: "+a.bruttoGehalt());
        System.out.println("Bruttolohn von a: "+a.nettoGehalt());

    }
}
