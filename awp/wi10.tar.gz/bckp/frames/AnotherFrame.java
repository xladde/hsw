
package frames;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


/**
 *
 * @author Thomas Jonitz
 */
public class AnotherFrame extends JFrame{

    private JTextArea input, output;
    private JButton okay;
    private JPanel top, main, bottom;

    public AnotherFrame() {
//        super("ANOTHER FRAME");
        setTitle("HELLO WORLD");
        // setSize(int breite, int hoehe)
        setSize(500, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        init();


        setVisible(true);
    }

    private void init(){
        input = new JTextArea("input here");
        output = new JTextArea("output here");
        okay = new JButton("OK");
        top = new JPanel();
        main = new JPanel();
        bottom = new JPanel();

        top.setLayout(new GridLayout(1,2));
        top.add(input);
        top.add(output);
        main.setLayout(new GridLayout(2,1));
        main.add(top);

        ActionListener al = new ActionListener() {
            public void actionPerformed(ActionEvent e){
                output.setText(input.getText());
            }
        };

        okay.setSize(100, 100);

        okay.addActionListener(al);
        bottom.setLayout(new BorderLayout());
        bottom.add(okay, BorderLayout.CENTER);

        bottom.add(new JPanel(), BorderLayout.NORTH);
        bottom.add(new JPanel(), BorderLayout.WEST);
        bottom.add(new JPanel(), BorderLayout.EAST);
        bottom.add(new JPanel(), BorderLayout.SOUTH);


        main.add(bottom);
        add(main);

    }

}
