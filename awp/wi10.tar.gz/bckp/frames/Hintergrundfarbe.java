
package frames;

import java.awt.Color;
import javax.swing.JFrame;

/**
 *
 * @author Thomas Jonitz
 */
public class Hintergrundfarbe {

    public static void main(String[] args){

//        JFrame frame = new JFrame();
//        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        frame.getContentPane().setBackground(new Color(255,0,0));
//        frame.setLocationRelativeTo(null);
//        frame.setSize(250,100);
//        frame.setVisible(true);
        new AnotherFrame();

    }

}
