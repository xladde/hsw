
package frames;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

/**
 *
 * @author Sebastian Zosel, Bassam Al-Hakimi, Thomas Jonitz
 *
 * Das extends identifiziert die Klasse, als Child von JFrame
 * -> Siehe Vererbung
 */
public class MyJFrame extends JFrame {

    // ---------------------------------------------------- INSTANZVARIABLEN ---
    Container c;                                                                // Als "Datenablage" - beinhaltet schlussendlich alle Objekte
    JList liste;                                                                // Eine einfache JList als Beispiel
    JPanel panel1;                                                              // Ein JPanel für das gesamte Layout
    JButton button1;                                                            // Ein einfacher Button als Beispiel

    // --------------------------------------------------------- KONSTRUKTOR ---
    /**
     * Erzeugt ein Objekt vom Typ MyJFrame, als Unterklasse von JFrame
     * @param title - Der Titel, des Fensters
     * @param visibilty - Boolean, ob das Fenster sichbra sein soll
     */
    public MyJFrame(String title, boolean visibilty){
        System.out.println("class frames.MyJFrame\n===");
        System.out.println("Setze Fenstertitel, Groesse, Position, Close-Operation");
        this.setTitle(title);                                                   // Fenstertitel setzen
        this.setSize(600, 600);                                                 // Größe des Fensters in Bildpunkten (Integer-Werte)
        this.setLocationRelativeTo(null);                                       // Fenster Mittig im Bildschirm anordnen
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);                           /*
                                                                                 * Handling beim Schließen des Fensters
                                                                                 * EXIT_ON_CLOSE ist eine Integer-Konstante
                                                                                 * die dazu dient, die Operation zu identifizieren.
                                                                                 * Ein weiteres Beispiel ist HIDE.
                                                                                 * Diese versteckt das fenster aber nur.
                                                                                 * Das Programm wird aber nicht beendet und das Objekt
                                                                                 * nicht verworfen.
                                                                                 */

        c = this.getContentPane();                                              /*
                                                                                 * JFrame.getContentPane() wirft ein Objekt vom Typ
                                                                                 * Container zurück. Mit der Zuweisung zu c 
                                                                                 * (Instanzvariable vom Typ Container) werden die
                                                                                 * Datenablage und der Frame-Inhalt miteinander verknüpft
                                                                                 */
        System.out.println("Fenster initialisieren");
        init();                                                                 // Methode init() aufrufen
        System.out.println("Sichtbarkeit: true");
        this.setVisible(visibilty);                                             /*
                                                                                 * Übergabe des boolean-Parameters
                                                                                 * true = sichtbar
                                                                                 * false = unsichtbar
                                                                                 */
    }

    /**
     * Initialisieren der Komponenten innerhalb des Fensters
     *
     * Der Übersicht halber trennt man das Layouten, etc. vom Konstruktor.
     * Hier erfolgt der meiste Schreibkram beim Programmieren. Das übernimmt
     * NetBeans für uns.
     *
     * Hier spielt die Reihenfolge der Initialisierungen eine entscheidende Rolle,
     * da Objekte auf andere Objekte, auf den Ebenen von oben nach unten abgelegt werden.
     * Wenn ein Objekt (Panel, Button, ComboBox, ...) ezeugt wurden ist es schwieriger
     * nachträglich andere Objekte darauf zu legen und zu modifizieren.
     * -> Siehe u.a. ModelViewController-Prinzip
     */
    public void init() {

// 1. LISTE DEFINIEREN (oberste Ebene, 1. Objekt)
        String[] listenInhalt= {"Sebastian", "Bassam", "Thomas"};               // Array beinhaltet die Objekte der JList
        liste = new JList(listenInhalt);                                        // Erzeugen der JList und übergabe der Inhalte
        
// 2. BUTTON DEFINIEREN (oberste Ebene, 2. Objekt)
        button1 = new JButton("Jim Knopf");                                     // Erzeugen eines JButton und übergabe des Textes

        /**
         * Auf den Button muss ein ActionListener gelegt werden, der das Objekt überwacht.
         * Nur so können Benutzereingaben (Mouseclick, ...) erkannt werden.
         * Die Methode JButton.addActionListener() erwartet als Übergabeparameter
         * ein Objekt vom Typ ActionListner
         */
        button1.addActionListener(new ActionListener() {                        /*
                                                                                 * ActionListner ist eine abstrakte
                                                                                 * Klasse und kann daher NICHT instaziiert werden.
                                                                                 * Daher entsteht an dieser Stelle diese exotische
                                                                                 * Verschachtelung.
                                                                                 */

            public void actionPerformed(ActionEvent evt) {                      /*
                                                                                 * actionPerformed() ist eine abstrakte Methode der
                                                                                 * Klasse ActionListner. Also eine Methode ohne "Rumpf".
                                                                                 *          Rumpf => {...}
                                                                                 * Hier wird der auszuführende Algorithmus definiert.
                                                                                 * Was soll passieren, wenn der button gedrückt wird
                                                                                 */
                System.out.println("Starte 2. Fenster");
                MyJFrame nummer2 = new MyJFrame("Hallo Welt 2", true);          // In diesem Fall wird einfach ein neues MyJFrame erzeugt.
            }                                                                   // -- Ende actionPerformed
        }                                                                       // -- Ende new ActionListner()
        );                                                                      // -- Ende addActionListner => Ende der Anweisung

// 3. PANEL DEFINIEREN (mittlere Ebene, 1. und einziges Objekt)
        panel1 = new JPanel();                                                  // Erzeugen des Panels

        panel1.setLayout(new GridLayout(1,2));                                  /*
                                                                                 * LayoutManger festlegen. Hier: GridLayout
                                                                                 * Der LM organisiert die Anordnung der Komponenten
                                                                                 * auf dem Objekt. Das GridLayout teilt das Objekt (JPanel)
                                                                                 * in gleichgroße Zeilen und Spalten (beides Integer-Werte),
                                                                                 * die als Parameter übergeben werden. Hier: 1 Zeile, 2 Spalten
                                                                                 */

        panel1.add(liste);                                                      /*
                                                                                 * Listenobjekt der höheren Ebene
                                                                                 * auf das Panel legen
                                                                                 */

        panel1.add(button1);                                                    /*
                                                                                 * Buttonobjekt der höheren Ebene
                                                                                 * auf das Panel legen
                                                                                 */

// 4. CONTAINER DEFINIEREN (unterste Ebene, letztes Objekt)
        c.add(panel1);                                                          /*
                                                                                 * Panelobjekt der höheren Ebene
                                                                                 * in den Container legen
                                                                                 */
    }                                                                           // ENDE der init()-Methode
}
