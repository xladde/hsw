package anwprog_wi10;


import frames.MyJFrame;
import java.awt.GridLayout;
import java.util.HashMap;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import taschenrechner.*;
import tabelle.*;
import pulldown.*;

/**
 *
 * @author WI09045
 */
public class Main {

    private static final Object[] BOX_ITEMS = {
        "Taschenrechner", "Einfache Tabelle", "PullDown-Menü", "JFrame",
        "Auswahldialog"
    };
    private static final HashMap<Object, Integer> HASH_MAP = new HashMap<Object, Integer>();
//    private static final int FRAME_WIDTH = 300;
//    private static final int FRAME_HEIGHT = 200;
    private static final String FRAME_TITLE = new String("Anwendungsprogrammierung WI10");


    private static void action(Object boxItem){
        for(int i = 0; i<BOX_ITEMS.length; i++){
            HASH_MAP.put(BOX_ITEMS[i], i);
        }
        switch(HASH_MAP.get(boxItem.toString())){
            case 0: Taschenrechner tr = new Taschenrechner();
                    tr.setVisible(true);
                    break;
            case 1: NewTable nt = new NewTable();
                    break;
            case 2: Menue me = new Menue();
                    me.setVisible(true);
                    break;
            case 3: MyJFrame mf = new MyJFrame("MyJFrame", true);
                    mf.setVisible(true);
                    break;
            case 4: new auswahldialoge.Frame();
                    break;

        }
    }

    private static void out(String s){
        System.out.println(s);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        out("Starting ...\ninitializing Frame Main");
        final JComboBox box = new JComboBox(BOX_ITEMS);


        JButton startApp = new JButton("START");
        startApp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                action(box.getSelectedItem());
                System.out.println("Starte " + box.getSelectedItem());
            }
        });

        JPanel panelLow = new JPanel();
        JPanel panelHigh = new JPanel();
        panelHigh.setLayout(new GridLayout(1,2));
        panelHigh.add(box);
        panelHigh.add(startApp);
        panelLow.setLayout(new GridLayout(2,1));
        panelLow.add(new JLabel("Seminaruebungen"));
        panelLow.add(panelHigh);


        JFrame frame = new JFrame(FRAME_TITLE);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.add(panelLow);
        frame.pack();
        frame.setVisible(true);
    }

}
