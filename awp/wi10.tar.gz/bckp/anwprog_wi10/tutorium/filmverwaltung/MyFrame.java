
package anwprog_wi10.tutorium.filmverwaltung;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

/**
 *
 * @author Thomas Jonitz
 */
public class MyFrame extends JFrame{

    private JTextField titel, jahr, regie;
    private JButton senden, ausgabe;
    private JPanel panel, bpanel;
    private Container c;
    private Filmverwaltung fv;

    public MyFrame(int hoehe, int breite, String fenstertitel){
        super(fenstertitel);

        titel = new JTextField();
        jahr = new JTextField();
        regie = new JTextField();
        senden = new JButton("Speichern");
        ausgabe = new JButton("Print Liste");
        panel = new JPanel();
        bpanel = new JPanel();
        c = this.getContentPane();
        fv = new Filmverwaltung();

        senden.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String title = titel.getText();
                String reg = regie.getText();
                int year = Integer.parseInt(jahr.getText());
                fv.add(title, year, reg);
                titel.setText("");
                regie.setText("");
                jahr.setText("");
            }
        });

        ausgabe.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.out.println(fv.toString());
            }
        });

        this.setSize(breite, hoehe);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);

        bpanel.setLayout(new GridLayout(1, 2));
        bpanel.add(senden);
        bpanel.add(ausgabe);

        panel.setLayout(new GridLayout(4, 1));
        panel.add(titel);
        panel.add(jahr);
        panel.add(regie);
        panel.add(bpanel);

        c.add(panel);

        this.setVisible(true);


    }



}
