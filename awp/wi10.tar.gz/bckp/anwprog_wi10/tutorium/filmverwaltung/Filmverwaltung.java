
package anwprog_wi10.tutorium.filmverwaltung;

import java.util.ArrayList;

/**
 *
 * @author Thomas Jonitz
 */
public class Filmverwaltung {

    private ArrayList<Film> liste;
    private int counter;

    public Filmverwaltung(ArrayList<Film> liste) {
        this.liste = liste;
        counter = liste.size();
    }

    public Filmverwaltung() {
        liste = new ArrayList<Film>(); // Instanzieren
        counter = 0;
    }


    public void add(Film f){
        liste.add(f);
        counter++;
    }

    public void add(String title, int year, String regie) {
        Film f = new Film(title, year, regie);
        liste.add(f);
        counter++;
    }

    public int getCounter() {
        return counter;
    }

    @Override
    public String toString(){
        String str = "";

        for(int i = 0; i < counter; i++) {
            Film f = getFilm(i);
            str +=  f.getTitle() + "\t" + f.getYear() +
                    "\t" + f.getRegie() + "\n";
        }
        return str;
    }


    public Film getFilm(int i){
        if(i < liste.size()) {
            return liste.get(i);
        } else {
            return liste.get(liste.size()-1);
        }
    }
    




    

    
}
