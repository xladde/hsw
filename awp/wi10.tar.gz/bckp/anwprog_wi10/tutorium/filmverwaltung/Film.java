package anwprog_wi10.tutorium.filmverwaltung;



// 1. Schritt: Klassendeklaration
public class Film {

    // 2. Schritt: Instanzvariablen deklarieren
    private String title;
    private int year;
    private String regie;

    // 3. Schritt: Konstruktor definieren
    public Film(String title, int year, String reg) {
        this.title = title;
        this.year = year;
        regie = reg;
    }

    // 4. Schritt: Getter und Setter (soweit benötigt)
    public String getRegie() {
        return regie;
    }

    public void setRegie(String regie) {
        this.regie = regie;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }
}



    
  