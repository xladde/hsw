package anwprog_wi10.tutorium;

import anwprog_wi10.tutorium.filmverwaltung.*;

public class Tutorium {

    public static void main(String[] args){

        MyFrame f = new MyFrame(500,600, "Filme");
    }
}