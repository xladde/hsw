
package anwprog_wi10.tutorium.polynomfunktion;

/**
 *
 * Diese Klasse repräsentiert ein Polynom einer Polynomfunktion.
 * @author Thomas Jonitz
 * @version 1.2
 * @date 6.6.2012
 */
public class Polynom {
    private double koeffizient;
    private double exponent;

    /**
     * Dies ist der Konstruktor.
     * Es ist ein toller konstruktor.
     *
     * @param koeffizient Der Koeffizient einer Funktion als Double-Wert
     * @param exponent Der Exponent einer Funktion als Double-Wert
     */
    public Polynom(double koeffizient, double exponent) {
        this.koeffizient = koeffizient;
        this.exponent = exponent;
    }

    /**
     * Den Exponenten liefern
     *
     * @return Double-Wert
     */
    public double getExponent() {
        return exponent;
    }

    public void setExponent(double exponent) {
        this.exponent = exponent;
    }

    public double getKoeffizient() {
        return koeffizient;
    }

    public void setKoeffizient(double koeffizient) {
        this.koeffizient = koeffizient;
    }


}
