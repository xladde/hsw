
package anwprog_wi10.tutorium.polynomfunktion;

import javax.swing.*;
import java.awt.*;

import java.util.*;
import java.util.Map.*;

/**
 *
 * @author Thomas Jonitz
 */
public class DrawDialog extends JDialog{

    public DrawDialog(Maske parent, HashMap<Double, Double> map) {
        super(parent);
        this.setSize(200,200);
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);


        JPanel p = new JPanel();
        this.add(p);
        this.setVisible(true);

        Graphics g = p.getGraphics();
        int last[] = new int[2];
        last[0] = 0;
        last[1] = 0;

        // Durchiterieren
        for(Entry<Double, Double> e: map.entrySet()) {
            double x = (double) e.getKey();
            double y = (double) e.getValue();
            g.drawLine(1, 1, 100, 100);
            last[0] = (int) x;
            last[1] = (int) y;
        }
        p.update(g);

       
       
    }
}
