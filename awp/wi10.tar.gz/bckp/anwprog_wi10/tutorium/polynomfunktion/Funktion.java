
package anwprog_wi10.tutorium.polynomfunktion;

import java.util.*;

/**
 *
 * @author Thomas Jonitz
 */
public class Funktion {

    private ArrayList<Polynom> fkt;

    public Funktion(double koef, double exp) {
        fkt = new ArrayList<Polynom>();
        fkt.add(new Polynom(koef, exp));
    }

    public Funktion(Polynom p) {
        fkt = new ArrayList<Polynom>();
        fkt.add(p);
    }

    public Funktion(ArrayList<Polynom> fkt) {
        this.fkt = fkt;
    }

    public void addPolynom(Polynom p) {
        fkt.add(p);
    }

    public void addPolynom(double koef, double exp) {
        fkt.add(new Polynom(koef, exp));
    }

    public Polynom getPolynom(int index) {
        return fkt.get(index);
    }

    public double getY(double x) {
        double y = 0;
        for(Polynom p: fkt) {
            y += p.getKoeffizient()*Math.pow(x, p.getExponent());
        }
        return y;
    }

}
