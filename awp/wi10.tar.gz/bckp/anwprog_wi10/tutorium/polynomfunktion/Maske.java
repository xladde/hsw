
package anwprog_wi10.tutorium.polynomfunktion;


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

/**
 *
 * @author Thomas Jonitz
 */
public class Maske extends JFrame {

    private JPanel panel;
    private JTextField tfCoef;
    private JTextField tfExp;
    private JTextField tfAnz;
    private JTextField tfAbst;

    private JButton bAddPoly;
    private JButton bMalen;

    private Funktion f;

    public Maske(){
        super("Funktion malen");
        f = new Funktion(0,0);
        this.setSize(500, 500);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);

        tfCoef = new JTextField("Koeffizient");
        tfExp = new JTextField("Exponent");
        tfAnz = new JTextField("Anzahl der Berechnungen");
        tfAbst = new JTextField("Abstand der Berechnungen");

        bAddPoly = new JButton("Fuege hinzu");
        bAddPoly.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addPolynom();
            }
        });


        bMalen = new JButton("Funktion malen");
        bMalen.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                malen();
            }
        });

        panel = new JPanel();
        panel.setLayout(new GridLayout(3,2));
        panel.add(tfCoef);
        panel.add(tfExp);
        panel.add(tfAnz);
        panel.add(tfAbst);
        panel.add(bAddPoly);
        panel.add(bMalen);


        this.add(panel);
        this.setVisible(true);
    }

    public void addPolynom() {
        double coef = Double.parseDouble(tfCoef.getText());
        double exp = Double.parseDouble(tfExp.getText());
        f.addPolynom(new Polynom(coef, exp));
    }

    public void malen() {
        double x = 0;
        HashMap<Double, Double> map = new HashMap<Double, Double>();
//        for(int i = 0; i < Integer.parseInt(tfAnz.getText()); i++){
//            map.put(x, f.getY(x));
//            x += Double.parseDouble(tfAbst.getText());
//
//        }
        for(int i = 0; i < 10; i++) {
            map.put(new Double(i), new Double(i));
        }
        // make dialog here ...
        new DrawDialog(this, map);
    }

}
