
package anwprog_wi10.tutorium.polynomfunktion;

/**
 *
 * @author Thomas Jonitz
 */
public class Test {

    public static void main(String[] args) {

        Funktion f1 = new Funktion(1,2);
        f1.addPolynom(7, 3);
        f1.addPolynom(-5, 1);
        f1.addPolynom(2, 0);

        //Maske m = new Maske();
        System.out.println("Ergebnis für x = 5: "+f1.getY(5));



    }
}
