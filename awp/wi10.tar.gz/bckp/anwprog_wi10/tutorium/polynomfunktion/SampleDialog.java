
package anwprog_wi10.tutorium.polynomfunktion;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.AffineTransform;

import java.util.*;
import java.util.Map.*;

/**
 *
 * @author Thomas Jonitz
 */
public class SampleDialog extends JDialog{

    final AffineTransform FLIP_X_COORDINATE;
    private JPanel p;

    public SampleDialog(JFrame parent, HashMap map) {
        super(parent);
        FLIP_X_COORDINATE = new AffineTransform(1, 0, 0, -1, 0, this.getHeight());
        this.setSize(200,200);
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        p = new JPanel();

        draw(map);

        this.add(p);
        this.setVisible(true);
    }

    private void draw(HashMap map) {
        Graphics2D g = (Graphics2D) getGraphics();
        g.setTransform(FLIP_X_COORDINATE);
        g.drawLine(0, 0, 250, 250);
    }
}
