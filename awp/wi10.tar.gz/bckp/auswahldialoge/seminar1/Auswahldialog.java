
package auswahldialoge.seminar1;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javax.swing.JColorChooser;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JTextArea;

/**
 *
 * @author Thomas Jonitz
 */
public class Auswahldialog extends JFrame {

    private JPanel main;
    private JMenuBar menuBar;
    private JMenuItem fChoose;
    private JMenuItem cChoose;
    private JTextArea log;


    private JFrame getThis(){
        return this;
    }

    public void addText(String txt){
        log.setText(log.getText()+"\n"+txt);

    }

    public Auswahldialog(){
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        log = new JTextArea();
        menuBar = new JMenuBar();
        fChoose = new JMenuItem("File Chooser");
        cChoose = new JMenuItem("Color Chooser");


        fChoose.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JFileChooser fc = new JFileChooser();
                int a = fc.showDialog(getThis(), "OkayButton"); // liefert 0 für "Okay", liefert 1 für "Abbrechen"
                System.out.println(a);
                System.out.println(JFileChooser.CANCEL_OPTION);
                if( a != JFileChooser.CANCEL_OPTION){ // Dialog korrekt beendet? a==0?
                    File f = fc.getSelectedFile();
                    log.setText("Gewählte Datei:\t"+f.getName()+
                            "\nPfad:\t\t"+f.getPath());
                }
            }
        });
        cChoose.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Color c = JColorChooser.showDialog(getThis(), "Farbauswahl", Color.black);
                if(c != null){
                    log.setText("Rot:\t"+c.getRed()
                    +"\nGrün:\t"+c.getGreen()
                    +"\nBlau:\t"+c.getBlue());
                }
            }
        });

        menuBar.add(fChoose);
        menuBar.add(cChoose);
        main = new JPanel();
        main.setLayout(new BorderLayout());
        main.add(menuBar, BorderLayout.NORTH);
        main.add(log, BorderLayout.CENTER);
        
        add(main);    
        
        pack();
        setVisible(true);
    }
    
    
    public static void main(String[] args){
        new Auswahldialog();
    }

}
