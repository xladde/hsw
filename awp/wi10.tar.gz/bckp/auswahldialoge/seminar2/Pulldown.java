
package auswahldialoge.seminar2;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javax.swing.*;

/**
 *
 * @author Thomas Jonitz
 */
public class Pulldown extends JFrame {

    private JMenu menu;
    private JMenuBar menuBar;
    private JMenuItem fChooser;
    private JMenuItem cChooser;
    private JTextArea ta;

    private JPanel main;

    private JFrame getThis(){
        return this;
    }

    public Pulldown(){
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setMinimumSize(new Dimension(400,200));
        // Menüleiste erstellen
        menu = new JMenu("Open");
        menuBar = new JMenuBar();
        fChooser = new JMenuItem("Open File");
        cChooser = new JMenuItem("Open Color");

        ActionListener alColor = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // showDialog gibt ein Objekt vom Typ Color zurück
                // Darin stehen die Farbwerte der gewählten Farbe
                Color color = JColorChooser.showDialog(getThis(), "Farbauswahl", Color.blue);
                ta.setText("Blau:\t"+color.getBlue()+
                        "\nGrün:\t"+color.getGreen()+
                        "\nRot:\t"+color.getRed());
            }
        };
        
        cChooser.addActionListener(alColor);

        fChooser.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JFileChooser fc = new JFileChooser();
                // showDialog gibt 0 für "Okay" zurück und 1 für "abbrechen"
                int a = fc.showDialog(getThis(), "OkeliDokeli");
                if(a != fc.CANCEL_OPTION){
                    File file = fc.getSelectedFile();
                    ta.setText("Datei:\t"+file.getName());
                }

            }
        });

//        ActionListener al2 = new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                // TODO
//            }
//        };

        menu.add(fChooser);
        menu.add(cChooser);
        menuBar.add(menu);
        // Textfeld erstellen
        ta = new JTextArea();
        // panel erstellen
        main = new JPanel();
        main.setLayout(new BorderLayout());
        main.add(menuBar, BorderLayout.NORTH);
        main.add(ta, BorderLayout.CENTER);

        // panel in das JFrame legen
        this.add(main);


        pack(); // Fensterbreite dynamisch anpassen
        setVisible(true);
    }

    public static void main(String[] args){
        new Pulldown();
    }

}
