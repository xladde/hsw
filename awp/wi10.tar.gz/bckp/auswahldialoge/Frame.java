// Aktuelles Paket
package auswahldialoge;

// Importe
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JColorChooser;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JTextArea;

/**
 * Klasse erzeugt ein Fenster mit JMenu(-Bar, -Item) und TextArea.
 * Kann Datei- und Farbauswahldialoge öffenen und deren selektierte Auswahl im
 * TextArea darstellen
 * @author Thomas Jonitz
 */
public class Frame extends JFrame {
    // INSTANZVARIABLEN
    // unmittelbare Elemente
    private JMenuBar menuBar;
    private JMenu menu;
    private JMenuItem fileChooserItem;
    private JMenuItem colorChooserItem;
    private JTextArea output;
    // Hilfselemente
    private JPanel mainPan;
    private Container c;

    /**
     * Konstruktor
     * Erzeugt ein Objekt des Typs
     * 1. Super-Konstruktor aufrufen
     * 2. Initialisierungsmethode aufrufen
     */
    public Frame(){
        super();
        initFrame();
    }// end Konstruktor

    /**
     * Initialisiert das Fenster und die darauf liegenden Objekte
     */
    private void initFrame(){
        setMinimumSize(new Dimension(300,300)); // Minimale Größe festlegen
        setDefaultCloseOperation(EXIT_ON_CLOSE); // Standart-Schließ-operation festlegen
        setLocationRelativeTo(null); // Fensterposition festlegen
        c = getContentPane();   // Fensterebene in den Conatiner
        mainPan = new JPanel(); // Hauptpanel erzeugen
        mainPan.setLayout(new BorderLayout());  // BorderLayout auf das Hauptpanel
        menuBar = new JMenuBar();   // Menüleiste erzeugen
        menu = new JMenu("Open Dialoges");  // Menü erzeugen
        fileChooserItem = new JMenuItem("Open File-Dialog"); // Menüpunkt erstellen für Dateiauswahldialog
        makeFileChooser(); // Dateiauswahldialog initialisieren (private Hilfsmethode)
        colorChooserItem = new JMenuItem("Open Color-Dialog");  // Menüpunkt für Farbauswahldialog erstellen
        makeColorChooser(); // Farbauswahldialog initialisieren (private Hilfsmethode)
        menu.add(fileChooserItem);  // Elemente aufeinander legen
        menu.add(colorChooserItem); // ...
        menuBar.add(menu);          // ...
        output = new JTextArea(); // neues Textfeld erzeugen
        output.setEditable(false); // Editierbarkeit einschränken
        mainPan.add(output, BorderLayout.CENTER); // Textfeld in die Mitte des Fensters
        mainPan.add(menuBar, BorderLayout.NORTH); // Menüleiste auf den oberen Bereich des Fensters
        c.add(mainPan); // ...
        pack(); // Breite anpassen
        setVisible(true);   // sichtbar machen
    }// end initFrame()

    /**
     * Hilfsmethode, um das Fenster anderen Objekten bekannt zu machen
     * @return
     */
    public JFrame getThis(){
        return this;
    }// end getThis

    /**
     * Private Hilfsmethode zum schreiben in das Textfeld
     * <code>JTextArea.setText(String str)</code> überschreibt den Inhalt
     * durch <code>getText()+"\n"+str</code> wird der neue text angefügt
     * <code>\n</code> ist das Steuersignal für Zeilenumbrüche
     * @param txt anzufügender String
     */
    private void writeToTextArea(String txt){
        output.setText(output.getText() + "\n" + txt);
    }// end writeToTextArea

    /**
     * Private Hilfsmethode, um den Dateiauswahldialog zu öffnen
     * 1. ActionListener auf das JMenuIcon legen
     * 2. Funktionalitäten bestimmen
     * 3. Rückgabe behandeln
     */
    private void makeFileChooser(){
        fileChooserItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // neuen JFileChooser erzeugen
                JFileChooser fileChooser = new JFileChooser();
                // Dateien und Verzeichnisse können ausgewählt werden
                fileChooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
                // nicht mehrere Dateien auswählen können
                fileChooser.setMultiSelectionEnabled(false);
                // Dialog-Titel setzen
                fileChooser.setDialogTitle("Choose a File ...");
                // Dialog anzeigen und auf Eingabe warten
                // Vergleich, ob etwas ausgewählt wurde, oder ob Abbrechen gewählt wurde
                // Beides sind Rückgabewerte vom Typ int -> daher der Vergleich
                if(fileChooser.showDialog(getThis(), "Okay") != JFileChooser.CANCEL_OPTION){
                    // Dateiobjekt erzeugen und mit ausgewählter Datei belegen
                    java.io.File newFile = fileChooser.getSelectedFile();
                    // Dateipfad und - Name in das Textfeld schreiben
                    writeToTextArea(newFile.toString());
                    java.io.File newFile2 = new java.io.File("HelloWorld.txt");
                    try {
                        newFile2.createNewFile();
                    } catch (IOException ex) {
                        Logger.getLogger(Frame.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }// end if
            }// end ectionPerformed
        });// end addActionListener
    }// end makeFileChooser

    /**
     * Private Hilfsmethode, um den Farbauswahldialog zu öffnen
     * 1. ActionListener auf das JMenuIcon legen
     * 2. Funktionalitäten bestimmen
     * 3. Rückgabe behandeln
     */
    private void makeColorChooser(){
        colorChooserItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // neuen ColorChooser-Dialog erzeugen (obsolet)
//                JColorChooser colorChooser = new JColorChooser();
                /**
                 * Dialog anzeigen, Titel setzen und Initial-farbauswahl setzen (hier: schwarz)
                 * die Methode showDialog zeigt den Farbauswahldialog an und liefert beim
                 * Beenden des Dialoges ein color-Objekt zurück, mit dem gearbeitet wird.
                 * Im Gegensatz zum JFileChooser ist die showDialog-Methode statisch. Es muss also
                 * kein Objekt diesen Typs erzeugt werden.
                 */
                Color color = JColorChooser.showDialog(getThis(), "Choose a Color", Color.black);
                if(color != null){ // Wenn eine Farbe ausgewählt wurde (also nicht leer)
                    // Rotwert in das Textfeld schreiben
                    writeToTextArea("Red:\t"+Integer.toString(color.getRed()));
                    // Grünwert in das Textfeld schreiben
                    writeToTextArea("Green:\t"+Integer.toString(color.getGreen()));
                    // Blauwert in das Textfeld schreiben
                    writeToTextArea("Blue:\t"+Integer.toString(color.getBlue()));
                }//end if
            }// end actionPerformed
        });// end addActionListener
    }// end makeColorChooser

    public static void main(String[] args){
        new Frame();
    }
}// end class Frame
