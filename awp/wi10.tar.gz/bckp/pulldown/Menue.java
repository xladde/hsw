
package pulldown;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

/**
 *
 * @author Thomas Jonitz
 */
public class Menue extends JFrame {

    // -------------------------------------------------------- INSTANZVARIABLEN
    private Container c;
    private JPanel panel;
    private JComboBox pulldown; // Objekt für Pull-Down-menü

    private JMenuBar bar;
    private JMenu menu1;
    private JMenu menu2;
    private JMenuItem item1;
    private JMenuItem item2;
    private String[] items= {"Hallo", "Welt", "Ausrufezeichen"};
    private ActionListener al;
    private Menue m;

    // ------------------------------------------------------------- KONSTRUKTOR
    public Menue(){
        super();
        setSize(200,100);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        init();
        setVisible(true);
        m = this;
    }

    // -------------------------------------------------------------- METHODE(N)
    private void init(){
        // Objekte erzeugen
        c = this.getContentPane();
        panel = new JPanel();
        pulldown = new JComboBox(items);
        bar = new JMenuBar();
        menu1 = new JMenu("Menu 1");
        menu2 = new JMenu("Menu 2");
        item1 = new JMenuItem("Item 1");
        item2 = new JMenuItem("Item 2");

        // Klickbar machen
        al = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Nachrichtenbox nb = new Nachrichtenbox(m, true);
                String txt = e.getActionCommand();
                nb.setText(txt);
                nb.setVisible(true);
                System.out.println("Hallo Welt");
            }
        };

        item1.addActionListener(al);
        item2.addActionListener(al);

        pulldown.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Nachrichtenbox nb = new Nachrichtenbox(m, true);
                nb.setText(pulldown.getSelectedItem().toString());
                nb.setVisible(true);
                System.out.println("Hallo World");
            }
        });

        // Objekte Stapeln
        panel.setLayout(new GridLayout(2,1));
        menu1.add(item1);
        menu1.add(item2);
        bar.add(menu1);
        bar.add(menu2);
        panel.add(bar);
        panel.add(pulldown);
        c.add(panel);

    }

    

}
