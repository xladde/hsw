
package fahrrad;

import java.util.ArrayList;

/**
 *
 * @author Thomas Jonitz
 */
public class Fahrrad {

    public static void main(String[] args) throws Exception {

        Komponente rahmen = new Komponente("Rahmen", 100);
        Baugruppe vrad = new Baugruppe("Vorderrad");
        Komponente vfelge = new Komponente("Felge vorne", 70);
        Komponente vmantel = new Komponente("Mantel vorne", 20);
        Baugruppe hrad = new Baugruppe("Hinterrad");
        Komponente hfelge = new Komponente("Felge hinten", 70);
        Komponente hmantel = new Komponente("Mantel hinten", 20);
        Komponente schaltung = new Komponente("Schaltung", 80);
        Komponente lenker = new Komponente("Lenker", 30);

        vrad.addElement(vfelge);
        vrad.addElement(vmantel);
        hrad.addElement(hfelge);
        hrad.addElement(hmantel);
        hrad.addElement(schaltung);

        ArrayList<Fahrradelement> bauteile = new ArrayList<Fahrradelement>();

        bauteile.add(vrad);
        bauteile.add(hrad);
        bauteile.add(lenker);
        bauteile.add(rahmen);

        // ------------------------------------------------------

        double summe = 0;
        for(int i = 0; i < bauteile.size(); i++) {
            summe += bauteile.get(i).berechnePreis();
        }

        System.out.println("Der Gesamtpreis lautet: " + summe + " Euro");

        // ---------------------------------
      
    }

}
