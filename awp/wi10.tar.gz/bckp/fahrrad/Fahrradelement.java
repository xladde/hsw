
package fahrrad;

/**
 *
 * @author Thomas Jonitz
 */
public abstract class Fahrradelement {

    private String name;

    public Fahrradelement(String name) {
        this.name = name;
    }

    public String getName(){
        return name;
    }

    public abstract double berechnePreis();

}
