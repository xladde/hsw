
package fahrrad;

import java.util.ArrayList;

/**
 *
 * @author Thomas Jonitz
 */
public class Baugruppe extends Fahrradelement {

    private ArrayList<Fahrradelement> liste;

    public Baugruppe(String name) {
        super(name);
        liste = new ArrayList<Fahrradelement>();
    }

    public void addElement(Fahrradelement fe){
        liste.add(fe);
    }

    public double berechnePreis() {
        double summe = 0;
        for(int i = 0; i < liste.size(); i++){
            summe = summe + liste.get(i).berechnePreis();
        }
        return summe;
    }

}
