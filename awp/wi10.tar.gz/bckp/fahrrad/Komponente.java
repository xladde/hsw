
package fahrrad;

/**
 *
 * @author Thomas Jonitz
 */
public class Komponente extends Fahrradelement {

    private double preis;

    public Komponente(String name, double preis) {
        super(name);
        this.preis = preis;
    }

    @Override
    public double berechnePreis() {
        return preis;
    }

}
