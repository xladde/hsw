
package kompass;

/**
 *
 * @author Thomas Jonitz
 */
public class Kompassrichtung {

    private int richtung;

    public Kompassrichtung(int winkel){
        if(winkel < 0 || winkel > 359) {
            throw new RuntimeException("Falscher Wert");
        }
        else {
            richtung = winkel;
        }
    }

    public int summe(int a, int b){
        return a+b;
    }

    public static void main(String[] args){
        new Kompassrichtung(256);
    }
}
