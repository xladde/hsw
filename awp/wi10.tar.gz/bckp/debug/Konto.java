
package debug;

public class Konto {

    // Klassenvariablen
    private static int testvar = 4711;
    // Instanzvariablen
    private int kontoNr;
    private double kontostand;

    
    /**
     * TODO Konstruktor erzeugen
     */
    void einzahlen(double betrag) {
        //...
    }

    void abheben(double betrag) {
        //...
    }

    

    double kontostandAbfragen() {
    //    ...
        return 0;
    }

    public static void main(String[] args) {
        // Referenzvariable
        Konto konto1 = new Konto();
        konto1.kontoNr = 123456;
        konto1.kontostand = 1000.0;
        Konto konto2 = new Konto();
        konto2.kontoNr = 234567;
        konto2.kontostand = 2000.0;
    }
}
