
package debug;

/**
 *
 * @author Thomas Jonitz
 */
public class Test {

    public Test() {

    }

    public int getSumme(int a, int b){
        return a+b;
    }

    public static void main(String[] args){
        Test t = new Test();
    }
}
