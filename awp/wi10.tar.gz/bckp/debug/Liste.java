
package debug;

/**
 * Dies ist eine einfache Klasse zur Listenverwaltung.
 * Man kann Objekte hinzufügen, auslesen und löschen.
 *
 * @author Thomas Jonitz
 * @version 2012-06
 * @date 6. june 2012
 */
public class Liste {

    /**
     * Dies ist die Instanzvariable, auf der wir arbeiten.
     */
    private java.util.ArrayList<Integer> l;

    /**
     * Konstruktor.
     * Konstruktoren erzeugen Objekte
     */
    public Liste(){
        l = new java.util.ArrayList<Integer>();
    }

    public void removeItem(int index){
        l.remove(index);
    }

    public void addItem(int item){
        l.add(item);
    }

    /**
     * Sich ein item aus der Liste holen macht Spass!
     * @param index Die Stelle, an der das gewünschte Objekt in der Liste liegt.
     * @return Das gewünschte Objekt, sofern es vorhanden ist. Andernfalls irgendwas anderes.
     */
    public int getItem(int index){
        return l.get(index);
    }

}
