
package debug;

/**
 *
 * @author Thomas Jonitz
 */
public class NewClass {

}
