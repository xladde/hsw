
package kreis;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.*;

/**
 *
 * @author Thomas Jonitz
 */
public class KreisMalen {

    private JFrame frame;
    private JPanel panel1;
    private JPanel panel2;
    private boolean firstClick;
    private boolean firstPoint;
    private int[] firstClick2;
    private int[] p2;
    private int[] p1;
    private java.awt.Graphics kreis;

    public KreisMalen() {
        firstClick = true;
        firstPoint = true;
        firstClick2 = new int[2];
        p1 = new int[2];
        p2 = new int[4];
        frame = new JFrame("Kreis Malen");

        frame.setSize(800,500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);

        panel1 = new JPanel();
        panel1.addMouseListener(new MouseListener() {
            public void mouseClicked(MouseEvent e) {
                zeichneK(e);
            }
            public void mousePressed(MouseEvent e){}
            public void mouseReleased(MouseEvent e){}
            public void mouseEntered(MouseEvent e){}
            public void mouseExited(MouseEvent e){}
        });

        panel2 = new JPanel();
        panel2.addMouseListener(new MouseListener() {
            public void mouseClicked(MouseEvent e) {
                zeichneP(e);
            }
            public void mousePressed(MouseEvent e){}
            public void mouseReleased(MouseEvent e){}
            public void mouseEntered(MouseEvent e){}
            public void mouseExited(MouseEvent e){}
        });

        frame.setLayout(new GridLayout(1,2));
        
        frame.add(panel1);
        frame.add(panel2);
        frame.setVisible(true);
    }

    public void zeichneK(MouseEvent e){
        kreis = panel1.getGraphics();
        kreis.drawRect(e.getX(), e.getY(), 1, 1);
        if(firstClick) {
            p1[0] = e.getX();
            p1[1] = e.getY();
            firstClick = false;
        } else {
            double a = ((e.getX()-p1[0])*(e.getX()-p1[0]));
            double b = ((e.getY()-p1[1])*(e.getY()-p1[1]));
            double r = Math.sqrt(a+b);
            double sx = (p1[0]-r);
            double sy = (p1[1]-r);

            
            kreis.drawOval((int) sx, (int) sy, (int) (2*r), (int) (2*r));
            firstClick = true;
        }      
    }

    public void zeichneP(MouseEvent e){
        kreis = panel2.getGraphics();
        kreis.drawRect(e.getX()-2, e.getY()-2, 5, 5);
        if(firstPoint){            
            p2[0] = e.getX(); p2[2] = e.getX();
            p2[1] = e.getY(); p2[3] = e.getY();
            firstPoint = false;
        } else { 
            kreis.drawLine(p2[0], p2[1], e.getX(), e.getY());
            
         //   boolean tmp = ((p2[2]-2 <= e.getX() || e.getX() < p2[2]+2)) && ((p2[3]-2 <= e.getY() || e.getY() < p2[3]+2));
       //     if(Math.abs(e.getX()-p2[0]) < 5 && Math.abs(e.getY()-p2[1]) < 5){
            double diff1 = Math.abs(p2[2]-e.getX());
            double diff2 = Math.abs(p2[3]-e.getY());
            if(diff1 <= 2 && diff2 <= 2) {
                firstPoint = true;
            }
            p2[0] = e.getX();
            p2[1] = e.getY();
        }
    }
}
