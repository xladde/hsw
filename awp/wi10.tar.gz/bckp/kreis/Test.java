
package kreis;

/**
 *
 * @author Thomas Jonitz
 */
public class Test {

    public static void main(String[] args){
        new KreisMalen();
    }
}
