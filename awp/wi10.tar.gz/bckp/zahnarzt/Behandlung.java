
package zahnarzt;

import java.util.*;

/**
 *
 * @author Thomas Jonitz
 */
public class Behandlung {

    private Date datum;
    private int patNr;

    private ArrayList<ZahnarztLeistung> al;

    public Behandlung(Date datum, int patNr) {
        this.datum = datum;
        this.patNr = patNr;
        al = new ArrayList<ZahnarztLeistung>();
    }

    public void addZahnarztLeistung(ZahnarztLeistung z){
        al.add(z);
    }

    public ZahnarztLeistung getZL(int index) {
        return al.get(index);
    }

    public double getGesamtGebuehr() {
        double summe = 0;
        for(int i = 0; i < al.size(); i++){
            summe = summe + al.get(i).getGebuehr();
        }
        return summe;
    }











        public Date getDatum() {
        return datum;
    }

    public void setDatum(Date datum) {
        this.datum = datum;
    }

    public int getPatNr() {
        return patNr;
    }

    public void setPatNr(int patNr) {
        this.patNr = patNr;
    }

}
