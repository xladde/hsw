
package zahnarzt;

/**
 *
 * @author Thomas Jonitz
 */
public class ZahnarztLeistung {

    private double gebuehr;
    private int zahnnummer;

    public ZahnarztLeistung(double gebuehr, int zahnnummer) {
        this.gebuehr = gebuehr;
        this.zahnnummer = zahnnummer;
    }

    public double getGebuehr() {
        return gebuehr;
    }

    public void setGebuehr(double gebuehr) {
        this.gebuehr = gebuehr;
    }

    public int getZahnnummer() {
        return zahnnummer;
    }

    public void setZahnnummer(int zahnnummer) {
        this.zahnnummer = zahnnummer;
    }



}
