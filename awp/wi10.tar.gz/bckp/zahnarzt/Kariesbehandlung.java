
package zahnarzt;

/**
 *
 * @author Thomas Jonitz
 */
public class Kariesbehandlung extends ZahnarztLeistung {

    private String fuellmaterial;

    public Kariesbehandlung(double gebuehr, int zahnnummer, String fuellmaterial) {
        super(gebuehr, zahnnummer);
        this.fuellmaterial = fuellmaterial;
    }

    public String getFuellmaterial() {
        return fuellmaterial;
    }

    public void setFuellmaterial(String fuellmaterial) {
        this.fuellmaterial = fuellmaterial;
    }

    
}
