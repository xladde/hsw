
package zahnarzt;

/**
 *
 * @author Thomas Jonitz
 */
public class Extraktion extends ZahnarztLeistung{

    private String narkosemittel;

    public Extraktion(double gebuehr, int zahnnummer, String narkosemittel) {
        super(gebuehr, zahnnummer);
        this.narkosemittel = narkosemittel;
    }

    public String getNarkosemittel() {
        return narkosemittel;
    }

    public void setNarkosemittel(String narkosemittel) {
        this.narkosemittel = narkosemittel;
    }

    
}
