
package einkaufsliste;

/**
 * Interfaces sind - ähnlich wie bei abstrakten Klassen - nur Beschreibungen,
 * welche Methoden eine implementierende Klasse mitbringen muss.
 *
 * Da es in Java keine Mehrfachvererbung gibt, wohl aber Mehrfachimplementierungen,
 * kann man in einer Klasse mehrere Funktionalitäten verschiedenster Objekte bereitstellen.
 *
 * So ist es nicht möglich eine Klasse nachstehender form zu schreiben
 * <code>public class IchTesteWas extends SuperKlasse1, SuperKlasse2, .. {}</code>
 * Wohl aber die Anweisung:
 * <code>public class IchTesteWas implements Interface1, Interface2, .. {}</code>
 * @author Thomas Jonitz
 */
public interface ELInterface {

    /**
     * Interfaces enthalten auch Konstanten
     */
    public final static int EINE_KONSTANTE = 0;

    public void addArtikel(Artikel a);
    public Artikel getArtikel(int nummer);
}
