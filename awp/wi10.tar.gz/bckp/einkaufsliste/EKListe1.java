
package einkaufsliste;

import java.util.HashMap;

/**
 * Klasse, die eine Zahl an Artikeln verwalten soll.
 * Für die Verwaltung ist eine HashMap vorghesehen. Eine HashMap speichert
 * Wertepaare, identifiziert durch einen Schlüssel.
 * Jedes Wertepaar hat also die Form:
 *      KEY -> Value
 *      KEY -> Value
 *      ...
 * Die Klasse erbt von <code>HashMap</code>, erhält damit alle Funktionalitäten und implementiert
 * das Interface <code>ELInterface</code>, verpflichtet sich also, die darin
 * deklarierten Methoden zu definieren.
 * @author Thomas Jonitz
 */
public class EKListe1   extends HashMap<Integer, Artikel>
                        implements ELInterface {

    /**
     * Konstruktor.
     * Der Konstruktor ruft den super()-Konstruktor der Klasse HashMap auf.
     * Bei Vererbung muss die erste Anweisung im Konstrukto immer super() sein,
     * ausser es handelt sich um eine abstrakte vererbende Klasse, die keinen
     * Konstruktor besitzt.
     */
    public EKListe1() {
        super();
    }

    /**
     * Implementierte Methode, um ein Artikel in die Einkaufsliste hinzuzufügen.
     * Die Bereitstellung der Methode ist durch die Implementierung des
     * Interfaces notwendig.
     * Es wird mit put ein Neues Wertepaar erzeugt. Dabei wird die Artikelnummer
     * als Schlüssel übergeben und der Artikel selbst als "Value".
     * Das new Integer erzeugt ein neues Integer-Objekt. HashMaps können keine primitiven
     * Datentypen verwalten, sind aber dennoch kompatibel in der Handhabung,
     * desshalb ist es eine reine Formsache, ein Objekt vom Typ Integer zu erzeugen.
     * 
     * @param a Objekt vom Typ <code>Artikel</code>
     */
    public void addArtikel(Artikel a) {
        put(new Integer(a.getArtnr()), a);
    }

    /**
     * Implementierte Methode, um ein Artikel aus der Einkaufsliste auszulesen.
     * Die Bereitstellung der Methode ist durch die Implementierung des
     * Interfaces notwendig. Es wird in der HashMap nach dem Schlüsselwert
     * <code>nummer</code> gesucht. Das dazugehörige Artikel-Objekt wird zurückgeliefert,
     * sofern dieses Vorhanden ist. Andernfalsl wird null zurückgeliefert.
     * @param nummer
     * @return
     */
    public Artikel getArtikel(int nummer) {
        if(containsKey(nummer)) {
            return get(nummer);
        } else {
            return null;
        }
    }
}
