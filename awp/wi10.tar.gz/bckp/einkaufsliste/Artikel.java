
package einkaufsliste;

/**
 * Klasse Artikel, als Basisklasse für die Einkaufsliste. Diese
 * Objekte sollen gespeichert werden. Die Klasse besteht nur aus wenigen Instanzvariable,
 * einem Konstruktor und den Getter und Setter
 * @author Thomas Jonitz
 */
public class Artikel {

    // Instanzvariablen

    private String bezeichnung;
    private int artnr;
    private double preis;

    /**
     * Konstruktor
     * @param bez Artikelbezeichnung
     * @param nummer Artikelnummer (später die Identifikationsnummer)
     * @param preis Einzelpreis des Artikels
     */
    public Artikel(String bez, int nummer, double preis) {
        bezeichnung = bez;
        this.preis = preis;
        artnr = nummer;
    }

    // SETTER UND GETTER

    public int getArtnr() {
        return artnr;
    }

    public void setArtnr(int artnr) {
        this.artnr = artnr;
    }

    public String getBezeichnung() {
        return bezeichnung;
    }

    public void setBezeichnung(String bezeichnung) {
        this.bezeichnung = bezeichnung;
    }

    public double getPreis() {
        return preis;
    }

    public void setPreis(double preis) {
        this.preis = preis;
    }

    
   
}
