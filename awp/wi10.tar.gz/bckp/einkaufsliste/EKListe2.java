
package einkaufsliste;

import java.util.HashMap;

/**
 * Klasse, die eine Zahl an Artikeln verwalten soll.
 * Für die Verwaltung ist eine HashMap vorghesehen. Eine HashMap speichert
 * Wertepaare, identifiziert durch einen Schlüssel.
 * Jedes Wertepaar hat also die Form:
 *      KEY -> Value
 *      KEY -> Value
 *      ...
 * Die Klasse implementiert das Interface <code>ELInterface</code> und verpflichtet sich damit
 * die darin enthaltenen Methoden zu definieren.
 * @author Thomas Jonitz
 */
public class EKListe2 implements ELInterface {

    //      HashMap<KEY,     VALUE  >
    private HashMap<Integer, Artikel> map;

    /**
     * Konstruktor initialisiert die HashMap
     */
    public EKListe2() {
        map = new HashMap<Integer, Artikel>();
    }

    /**
     * Implementierte Methode, um ein Artikel in die Einkaufsliste hinzuzufügen.
     * Die Bereitstellung der Methode ist durch die Implementierung des
     * Interfaces notwendig.
     * Es wird mit put ein Neues Wertepaar erzeugt. Dabei wird die Artikelnummer
     * als Schlüssel übergeben und der Artikel selbst als "Value".
     * Das new Integer erzeugt ein neues Integer-Objekt. HashMaps können keine primitiven
     * Datentypen verwalten, sind aber dennoch kompatibel in der Handhabung,
     * desshalb ist es eine reine Formsache, ein Objekt vom Typ Integer zu erzeugen.
     *
     * @param a Objekt vom Typ <code>Artikel</code>
     */
    public void addArtikel(Artikel a) {
        map.put(new Integer(a.getArtnr()), a);
    }

    /**
     * Implementierte Methode, um ein Artikel aus der Einkaufsliste auszulesen.
     * Die Bereitstellung der Methode ist durch die Implementierung des
     * Interfaces notwendig. Es wird in der HashMap nach dem Schlüsselwert
     * <code>nummer</code> gesucht. Das dazugehörige Artikel-Objekt wird zurückgeliefert,
     * sofern dieses Vorhanden ist. Andernfalsl wird null zurückgeliefert.
     * @param nummer
     * @return
     */
    public Artikel getArtikel(int nummer) {
        if(map.containsKey(nummer)) {
            return map.get(nummer);
        } else {
            return null;
        }
    }

    /**
     * Einface Methode, die "Hallo Welt" auf dem Bildschrim ausgibt.
     * Die Mthode kann aus der Testklasse nicht aufgerufen werden, da
     * dort mit einem Interface gearbeitet wird, dass lediglich Zugriff auf
     * die in ihm deklarierten Methoden hat. Also addArtikel() und getArtikel()
     */
    public void doSomething(){
        System.out.println("HALLO WELT");
    }
}
