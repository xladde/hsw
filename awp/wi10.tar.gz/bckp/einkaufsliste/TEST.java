
package einkaufsliste;


/**
 *
 * @author Thomas Jonitz
 */
public class TEST {

    public static final String[] ITEMS = {"Fahrrad", "Auto", "Brot", "Ueberraschungsei", "Intelligenz"};
    /**
     * Main-Methode
     * @param args übergebene Parameter
     */
    public static void main(String args[]) {

//        String[] argv;
//        if(args.length <= 1){
//          argv = ITEMS;
//        } else {
//          argv = args;
//        }
//
//        // Erste Einkaufsliste Erzeugen. Interface deklarieren, aber als EKListe1 initialisieren
//        ELInterface el1 = new EKListe1();
//        // zweite Einkaufsliste Erzeugen. Interface deklarieren, aber als EKListe2 initialisieren
//        ELInterface el2 = new EKListe2();
//
//        // Ein paar Artikel erzeugen und in den listen abglegen
//        for(int i = 0; i < argv.length; i++){
//            Artikel a = new Artikel(argv[i], i, (int) Math.random() * 100); // Artikel aus Liste erzeugen
//            el1.addArtikel(a); // el1 hinzufügen
//            el2.addArtikel(a); // el2 hinzufügen
//        }
//
//        // erste liste auslesen und testen
//        for(int i = 0; i < argv.length+1; i++) {
//            Artikel a = el1.getArtikel(i);
//            if(a == null) {
//                System.out.println("Artikel Nr. "+i+" ist in e1 nicht vorhanden");
//            } else {
//                System.out.println("Artikel Nr. "+a.getArtnr()+" bezeichnet: "+a.getBezeichnung()+ "und kostet: "+a.getPreis() );
//            }
//        }
//
//        // zweite liste auslesen und testen
//        for(int i = 0; i < argv.length+1; i++) {
//            Artikel a = el2.getArtikel(i);
//            if(a == null) {
//                System.out.println("Artikel Nr. "+i+" ist in e2 nicht vorhanden");
//            } else {
//                System.out.println("Artikel Nr. "+a.getArtnr()+" bezeichnet: "+a.getBezeichnung()+ "und kostet: "+a.getPreis() );
//            }
//        }
        
        

       

        


    }
}
