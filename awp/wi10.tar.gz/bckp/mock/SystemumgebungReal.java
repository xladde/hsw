
package mock;

/**
 *
 * @author Thomas Jonitz
 */
public class SystemumgebungReal implements Systemumgebung{

    public long getTime() {
        return System.currentTimeMillis();
    }

}
