
package mock;

/**
 *
 * @author Thomas Jonitz
 */
public interface Systemumgebung {

    public long getTime();
}
