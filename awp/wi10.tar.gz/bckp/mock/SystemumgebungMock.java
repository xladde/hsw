
package mock;

import java.util.Calendar;
import java.util.Date;

/**
 *
 * @author Thomas Jonitz
 */
public class SystemumgebungMock implements Systemumgebung {

    public SystemumgebungMock() {        
    }

    @Override
    public long getTime() {
        Calendar c = Calendar.getInstance();
        c.set(2012, 06, 13, 16, 38, 0);
        return c.getTimeInMillis();
    }
}
