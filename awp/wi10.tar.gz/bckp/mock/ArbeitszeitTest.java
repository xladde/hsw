
package mock;

import org.junit.Test; // TEST-Annotation importieren
import static org.junit.Assert.*; // Ergebnisvergleich

/**
 *
 * @author Thomas Jonitz
 */
public class ArbeitszeitTest {

    

    public ArbeitszeitTest() {
        
    }

    // 1. Vorbereiten

    public void setUp() {
        Systemumgebung su;
        Arbeitszeit az;
        //Systemumgebung erzeugen
        su = new SystemumgebungMock();
        az = new Arbeitszeit(su);
    }


    // Test durchführen
    @Test
    public void erinnereTest() {
        System.out.println(az.erinnere());
    }


    // zuletzt bereinigen
    public void tearDown() {

    }


}
