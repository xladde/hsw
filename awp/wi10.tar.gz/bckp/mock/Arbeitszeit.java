
package mock;

import java.util.Calendar;

/**
 *
 * @author Thomas Jonitz
 */
public class Arbeitszeit {

    private Systemumgebung su;

    public Arbeitszeit(Systemumgebung su) {
        this.su = su;
    }

    public boolean erinnere() {
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(su.getTime());
        int stunde = cal.get(Calendar.HOUR_OF_DAY);
        if(stunde >= 17) {
            System.out.println("Feierabend");
            return true;
        }
        return false;
    }
}
