
package observer;

/**
 *
 * @author Thomas Jonitz
 */
public class Buchung {

    private int menge;
    private String name;
    private double einzelpreis;
    private int zimmerNr;

    public Buchung(String name, int menge, double einzelpreis, int zimmerNr) {
        this.menge = menge;
        this.name = name;
        this.einzelpreis = einzelpreis;
        this.zimmerNr = zimmerNr;
    }

    public double getEinzelpreis() {
        return einzelpreis;
    }

    public int getMenge() {
        return menge;
    }

    public String getName() {
        return name;
    }

    public int getZimmerNr() {
        return zimmerNr;
    }

    
}
