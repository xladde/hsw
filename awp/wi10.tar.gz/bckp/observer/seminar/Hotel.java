
package observer.seminar;

import java.util.*;

/**
 *
 * @author Thomas Jonitz
 */
public class Hotel implements Observer {

    private double umsatz;

    public Hotel() {
        umsatz = 0;
    }

    public void update(Observable o, Object arg) {
        Buchung b = (Buchung) arg;
        double a = b.getEPreis()*b.getMenge();
        umsatz += a;
        System.out.println("Buchung: "+a);
        System.out.println("Gesamtumsatz Hotel: "+umsatz);
    }


}
