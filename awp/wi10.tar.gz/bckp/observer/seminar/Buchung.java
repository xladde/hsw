
package observer.seminar;

/**
 * Klasse Buchung dient als Dummy-Objekt
 * @author Thomas Jonitz
 */
public class Buchung {

    private String name;
    private double ePreis;
    private int menge;

    public Buchung(String name, double ePreis, int menge) {
        this.name = name;
        this.ePreis = ePreis;
        this.menge = menge;
    }

    public int getMenge() {
        return menge;
    }

    public double getEPreis() {
        return ePreis;
    }

    public String getName() {
        return name;
    }






}
