
package observer.seminar;

import java.util.ArrayList;
import java.util.Observable;

/**
 *
 * @author Thomas Jonitz
 */
public class BuchungsListe extends Observable {

    private ArrayList<Buchung> bl;

    public BuchungsListe(){
        bl = new ArrayList<Buchung>();
    }

    public void addBuchung(Buchung b){
        bl.add(b);
        this.setChanged();
        this.notifyObservers(b);
    }

    public Buchung getBuchung(int index){
        return bl.get(index);
    }
}
