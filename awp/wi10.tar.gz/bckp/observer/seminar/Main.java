
package observer.seminar;

/**
 *
 * @author Thomas Jonitz
 */
public class Main {
    
    public static void main(String[] args) {
        Hotel h = new Hotel();
        Gast  g = new Gast();
        BuchungsListe bl = new BuchungsListe();
        
        bl.addObserver(h);
        bl.addObserver(g);
    
        bl.addBuchung(new Buchung("buchung1", 2, 5));
        bl.addBuchung(new Buchung("buchung2", 5, 1));
    }
}
