
package observer.seminar;

import java.util.Observable;
import java.util.Observer;

/**
 *
 * @author Thomas Jonitz
 */
public class Gast implements Observer {
    private double umsatz;

    public Gast(){
        umsatz = 0;
    }

    public void update(Observable o, Object arg) {

        Buchung b = (Buchung) arg;
        umsatz+=b.getMenge()*b.getEPreis();
        System.out.println("Buchung: "+b.getMenge()*b.getEPreis());
        System.out.println("Gesamtumsatz Gast: "+umsatz);

    }

}
