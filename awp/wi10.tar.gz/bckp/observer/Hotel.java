
package observer;

import java.util.Observable;
import java.util.Observer;

/**
 *
 * @author Thomas Jonitz
 */
public class Hotel implements Observer{

    private double umsatz;

    public Hotel(){
        umsatz = 0;
    }

    public void update(Observable o, Object arg) {
        Buchung b = (Buchung) arg;
        umsatz += b.getEinzelpreis()*b.getMenge();
        System.out.println("Hotel: neue Buchung über "+ b.getEinzelpreis()*b.getMenge() +" Euro auf Zimmer  "+b.getZimmerNr() + " Gesamtumsatz: "+umsatz);
    }


}
