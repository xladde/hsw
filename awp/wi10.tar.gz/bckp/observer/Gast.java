
package observer;

import java.util.Observable;
import java.util.Observer;

/**
 *
 * @author Thomas Jonitz
 */
public class Gast implements Observer{

    private double umsatz;
    private int zimmerNr;

    public Gast(int zNr){
        zimmerNr = zNr;
        umsatz = 0;
    }

    public void update(Observable o, Object arg) {
        Buchung b = (Buchung) arg;
        umsatz += b.getEinzelpreis()*b.getMenge();
        System.out.println("Gast "+zimmerNr+": neue Buchung über "+ b.getEinzelpreis()*b.getMenge() +" Euro fuer "+b.getName());
    }
}
