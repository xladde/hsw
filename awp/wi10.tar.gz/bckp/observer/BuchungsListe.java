package observer;

import java.util.ArrayList;
import java.util.Observable;

/**
 *
 * @author Thomas Jonitz
 */
public class BuchungsListe extends Observable {

    private ArrayList<Buchung> buchungen;

    public BuchungsListe() {
        buchungen = new ArrayList<Buchung>();
    }


    public Buchung getBuchung(int index){
        return buchungen.get(index);
    }

    public void addBuchung(Buchung b){
        buchungen.add(b);
        this.setChanged();
        this.notifyObservers(b);
    }
}
