
package observer;

/**
 *
 * @author Thomas Jonitz
 */
public class Main {

    private static final int GAESTE = 2;
    private static final Buchung[] BUCHUNGEN = {
        new Buchung("Flasche Bier", 3, 3.50, 111),
        new Buchung("Restaurantservice", 1, 23.64, 111),
        new Buchung("Pay TV", 1, 20, 112),
        new Buchung("Uebernachtung", 7, 130, 113),
        new Buchung("Weckruf", 1, 5, 113)
    };

    public static void main(String[] args){
        
        BuchungsListe bl = new BuchungsListe();
        Hotel h = new Hotel();
        bl.addObserver(h);
        
        for(int i=0; i < GAESTE; i++){
            bl.addObserver(new Gast(i));

        }
        for(int i=0; i < GAESTE; i++){
            bl.addBuchung(BUCHUNGEN[i]);
            System.out.println("------------------------------------------------");
            
        }


    }

}
