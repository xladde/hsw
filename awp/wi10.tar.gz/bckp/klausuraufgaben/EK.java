
package klausuraufgaben;

/**
 *
 * @author Thomas Jonitz
 */
public class EK extends AK {

    public EK(int i) {
        super(i);
    }

    @Override
    public void printA() {
        this.printC();
    }
}
