public class Test {

	public static void main(String[] args) {
//		int ergebnis = 0;
//		for(int index = 0; index < args.length; index++){
//			ergebnis += Integer.parseInt(args[index]);
//		}
//		System.out.println("Ergebnis: "+ergebnis);
//		System.exit(0);

            new klausuraufgaben.MyJTable();
	}
}
