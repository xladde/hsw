
package klausuraufgaben;

/**
 *
 * @author Thomas Jonitz
 */
public abstract class AK {

    private int irgendwas;

    public AK(int irgendwas){
        this.irgendwas = irgendwas;
    }

    public abstract void printA();

    public static void printB(){
        System.out.println("HELLO WORLD PRINTB");
    }

    public void printC(){
        System.out.println("HELLO WORLD PRINTC");
    }

}
