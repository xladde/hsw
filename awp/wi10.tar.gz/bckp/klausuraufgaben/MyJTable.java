
package klausuraufgaben;

import javax.swing.*;

/**
 *
 * @author Thomas Jonitz
 */
public class MyJTable extends JFrame {

    private JScrollPane pane;
    private JTable tab;

    public MyJTable() {
        setSize(500,500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        System.out.println("Exit on close = " + EXIT_ON_CLOSE);
        // -------------------------------------------------------
        String[] headlines = {"ISBN", "Autor", "Titel", "Preis (EUR)"};
        /**
         * Der Content wird ZEILENWEISE gefüllt
         */
        Object[][] content = { // Arary mit tabellendaten anlegen
            {new Integer(032447634), "Thomas Jonitz", "AWP für Ultras", new Double(0)},
            {new Integer(313444234), "Ulrike Britting", "AWP für Subtras", new Double(1500)}
        };
        tab = new JTable(content, headlines);
        // --------------------------------------------------------
        pane = new JScrollPane(tab);
        this.add(pane);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
