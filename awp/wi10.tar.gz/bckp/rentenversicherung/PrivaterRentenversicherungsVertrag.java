
package rentenversicherung;

/**
 *
 * @author Thomas Jonitz
 */
public class PrivaterRentenversicherungsVertrag {

    private String vorname;
    private String nachname;
    private String adresse;
    private int laufzeit; // in Jahren

    public PrivaterRentenversicherungsVertrag(String vn, String nn, String adr, int lz) {
        vorname = vn;
        nachname = nn;
        adresse = adr;
        laufzeit = lz;
    }

    public String getAdresse() {
        return adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public int getLaufzeit() {
        return laufzeit;
    }

    public void setLaufzeit(int laufzeit) {
        this.laufzeit = laufzeit;
    }

    public String getNachname() {
        return nachname;
    }

    public void setNachname(String nachname) {
        this.nachname = nachname;
    }

    public String getVorname() {
        return vorname;
    }

    public void setVorname(String vorname) {
        this.vorname = vorname;
    }

    
}
