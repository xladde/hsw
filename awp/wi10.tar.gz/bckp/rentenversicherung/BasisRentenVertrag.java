
package rentenversicherung;

/**
 *
 * @author Thomas Jonitz
 */
public class BasisRentenVertrag extends PrivaterRentenversicherungsVertrag {

    private boolean hinterbliebenenRente;
    private double prozentsatz;

    public BasisRentenVertrag(String vn, String nn, String adr, int lz, boolean hinterbliebenenRente, double prozentsatz) {
        super(vn, nn, adr, lz);
        this.hinterbliebenenRente = hinterbliebenenRente;
        this.prozentsatz = prozentsatz;
    }

    public boolean isHinterbliebenenRente() {
        return hinterbliebenenRente;
    }

    public void setHinterbliebenenRente(boolean hinterbliebenenRente) {
        this.hinterbliebenenRente = hinterbliebenenRente;
    }

    public double getProzentsatz() {
        return prozentsatz;
    }

    public void setProzentsatz(double prozentsatz) {
        this.prozentsatz = prozentsatz;
    }

    

}
