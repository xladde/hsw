
package rentenversicherung;

/**
 *
 * @author Thomas Jonitz
 */
public class RiesterRentenVertrag extends PrivaterRentenversicherungsVertrag {
    private int anteilAktien;
    private int anteilFonds;
    private int anteilFestverzinslicheWertpapiere;

    public RiesterRentenVertrag(String vn, String nn, String adr, int lz, int anteilAktien, int anteilFonds, int anteilFestverzinslicheWertpapiere) {
        super(vn, nn, adr, lz);
        this.anteilAktien = anteilAktien;
        this.anteilFonds = anteilFonds;
        this.anteilFestverzinslicheWertpapiere = anteilFestverzinslicheWertpapiere;
    }

    public int getAnteilAktien() {
        return anteilAktien;
    }

    public void setAnteilAktien(int anteilAktien) {
        this.anteilAktien = anteilAktien;
    }

    public int getAnteilFestverzinslicheWertpapiere() {
        return anteilFestverzinslicheWertpapiere;
    }

    public void setAnteilFestverzinslicheWertpapiere(int anteilFestverzinslicheWertpapiere) {
        this.anteilFestverzinslicheWertpapiere = anteilFestverzinslicheWertpapiere;
    }

    public int getAnteilFonds() {
        return anteilFonds;
    }

    public void setAnteilFonds(int anteilFonds) {
        this.anteilFonds = anteilFonds;
    }

    


}
