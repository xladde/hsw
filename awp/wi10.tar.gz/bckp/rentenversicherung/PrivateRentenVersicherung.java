
package rentenversicherung;

/**
 *
 * @author Thomas Jonitz
 */
public class PrivateRentenVersicherung {
    private String name;
    private double gesamtEinzahlung;
    private int c;

    private PrivaterRentenversicherungsVertrag[] vertraege;

    public PrivateRentenVersicherung(String name, double gesamtEinzahlung) {
        this.name = name;
        this.gesamtEinzahlung = gesamtEinzahlung;

        vertraege = new PrivaterRentenversicherungsVertrag[1];
        c = 0;
    }

    public void addVertrag(PrivaterRentenversicherungsVertrag v) {
        if(c < vertraege.length) {
            vertraege[c] = v;
            c++;
        } else {
            // 1. temporäres Array anlegen zum sichern der alten werte
            PrivaterRentenversicherungsVertrag[] tmp = vertraege;

            // 2. altes array vergrößern
            vertraege = new PrivaterRentenversicherungsVertrag[tmp.length+1];

            // 3. zu fuß die werte rüberkopieren
            /*for(int i = 0; i < tmp.length; i++) {
                vertraege[i] = tmp[i];
            }*/
            // oder einfaches kopieren:
            System.arraycopy(tmp, 0, vertraege, 0, tmp.length);

            // rekursiver aufruf v hinzufügen
            addVertrag(v);
        }
    }

    public void printVertrag(int i){
        System.out.println(vertraege[i].getNachname() + ", " + vertraege[i].getVorname());
    }




    






    public double getGesamtEinzahlung() {
        return gesamtEinzahlung;
    }

    public void setGesamtEinzahlung(double gesamtEinzahlung) {
        this.gesamtEinzahlung = gesamtEinzahlung;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }




}
