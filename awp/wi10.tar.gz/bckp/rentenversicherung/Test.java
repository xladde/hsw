
package rentenversicherung;

/**
 *
 * @author Thomas Jonitz
 */
public class Test {

    public static void main(String[] args) {
        PrivateRentenVersicherung prv1 = new PrivateRentenVersicherung("Rentenversicherung1", 10000);
        prv1.addVertrag(new PrivaterRentenversicherungsVertrag("Karl", "Müller", "Wiesenweg 1", 20));
        prv1.addVertrag(new PrivaterRentenversicherungsVertrag("Michael", "Meier", "Wiesenweg 1", 20));
        prv1.addVertrag(new PrivaterRentenversicherungsVertrag("Gustav", "Schmidt", "Wiesenweg 1", 20));
        prv1.addVertrag(new PrivaterRentenversicherungsVertrag("Hans", "Hansen", "Wiesenweg 1", 20));

        prv1.printVertrag(0);
        prv1.printVertrag(1);
        prv1.printVertrag(2);
        prv1.printVertrag(3);
        

    }
}
