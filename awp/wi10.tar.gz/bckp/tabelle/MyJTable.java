
package tabelle;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;

/**
 *
 * @author Thomas Jonitz
 */
public class MyJTable {
    /**
     * Erstellen einer einfachen JTable in 3 Schritten. Durch das auslagern der
     * komponenten in eine Main-Methode wird direkt mit der Klasse JFrame garbeitet
     * anstatt eine eigene individuell angepasste klasse zu formen.
     *
     * @param args Übergabeparameter bei Programmstart
     */
    public static void main(String[] args){
// 1. DATENSATZ ERZEUGEN -------------------------------------------------------

        // String-Array der die Spaltenbezeichner beinhaltet
        String[] namen = {"Nr.", "Land", "PLZ", "ORT", "Distrct", "Straße", "Hausnummer"};
        // 2D-Array mit den Zeilendaten. Wird also zeilenweise gelesen
        // Object, um verschiedene Datentypen in einer Tabelle darzustellen
        Object[][] daten = {
            {new Integer(1), "Deutschland", "23966", "Wismar", "Friedenshof", "Phillip-Müller-Str.", "14"},
            {new Double(2), "Deutschland", "23966", "Wismar", "Friedenshof", "J.-R.-Becher-Str", "11"},
            {"3", "Deutschland", "23966", "Wismar", "Friedenshof", "Friedrich-Wolf-Str.", "23"},
        };

// 2. TABELLE ERZEUGEN ---------------------------------------------------------
        //Tabelle durch konstruktoraufruf erzeugen
        JTable table = new JTable(daten, namen);

// 3. FENSTER ERZEUGEN ---------------------------------------------------------
        // Fenster erzeugen und anpassen
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(new JScrollPane(table)); // ScrollPane ist ein Layer zum verwalten von JTables.
        frame.pack(); // dynamischere fenstergröße
        frame.setVisible(true);

    }
}
