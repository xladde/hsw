
package tabelle;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;

/**
 *
 * @author Thomas Jonitz
 */
public class NewTable {
    private String[] namen = {"Nr.", "Land", "PLZ", "ORT", "Distrct", "Straße", "Hausnummer"};
    private Object[][] daten = {
            {new Integer(1), "Deutschland", "23966", "Wismar", "Friedenshof", "Phillip-Müller-Str.", "14"},
            {new Double(2), "Deutschland", "23966", "Wismar", "Friedenshof", "J.-R.-Becher-Str", "11"},
            {"3", "Deutschland", "23966", "Wismar", "Friedenshof", "Friedrich-Wolf-Str.", "23"},
        };

    public NewTable(){
        System.out.println("class tabelle.NewTable\n===");
        JTable table = new JTable(daten, namen);
        JFrame frame = new JFrame();
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.add(new JScrollPane(table)); // ScrollPane ist ein Layer zum verwalten von JTables.
        frame.pack(); // dynamischere fenstergröße
        frame.setVisible(true);
    }

}
