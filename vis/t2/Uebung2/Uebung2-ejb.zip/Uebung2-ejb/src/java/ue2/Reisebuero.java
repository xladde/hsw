/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ue2;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author marian
 */
@Stateless
public class Reisebuero implements ReisebueroRemote {
    
    @PersistenceContext
    private EntityManager manager;

    @Override
    public void createKunde(Kunde k) {
        manager.persist(k);
    }

    @Override
    public Kunde findeKunde(Long pKey) {
        return manager.find(Kunde.class, pKey);
    }

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")

    @Override
    public List sucheKunde(String nachname) {
        Query query = manager.createQuery("select k from Kunde k where k.nachname=:nn");
        query.setParameter("nn", nachname);
        return query.setMaxResults(5).setFirstResult(0).getResultList();
    }
}
