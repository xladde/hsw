/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ue2;

import javax.ejb.Remote;

/**
 *
 * @author marian
 */
@Remote
public interface ReisebueroRemote {
    
    public void createKunde(Kunde k);
    public Kunde findeKunde(Long pKey);
    public java.util.List sucheKunde(String nachname);
    
}
